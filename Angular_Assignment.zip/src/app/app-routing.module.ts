import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: "", redirectTo: "routeimage", pathMatch: "full"
  },
  {
    path: 'routeimage',
    loadChildren: () => import('./module/route1-image/route1-image.module').then(m => m.Route1ImageModule)
  },
  {
    path: 'ecommerce',
    loadChildren: () => import('./module/ecommerce/ecommerce.module').then(m => m.EcommerceModule)
  },
  {
    path: 'countdown',
    loadChildren: () => import('./module/countdown/countdown.module').then(m => m.CountdownModule)
  },
  {
    path: 'coountdownusingrxjs',
    loadChildren: () => import('./module/countdownusingrxjs/countdownusingrxjs.module').then(m => m.CountdownusingrxjsModule)
  },
  {
    path: 'student',
    loadChildren: () => import('./module/student/student.module').then(m => m.StudentModule)
  },
  {
    path: 'dynamic',
    loadChildren: () => import('./module/dynamic/dynamic.module').then(m => m.DynamicModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
