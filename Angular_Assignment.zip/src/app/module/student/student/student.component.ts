import { Component, OnInit, OnDestroy } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit, OnDestroy {
  studentsData: any = [];
  studentsColumns: any = [];
  studentsBackup: any = [];
  click: any = 0;
  constructor(private studentService: StudentService) { }

  ngOnInit(): void {
    this.fetchStudentsRecord();
  }

  public fetchStudentsRecord() {
    this.studentService.getStudentData().subscribe({
      next: (res) => {
        console.log(res);
        this.studentsData = res.studentsData;
        this.studentsColumns = res.sudentsColumn;
        this.studentsBackup = JSON.parse(JSON.stringify(res.studentsData));
      },
      error: (error) => console.log(error)
    })
  }

  public sortData(event: any, field: any) {
    this.click = this.click + 1;

    if (this.click === 1) {
      this.ascendingOrder(this.studentsData, field);
    } else if (this.click === 2) {
      this.descendingOrder(this.studentsData, field);
    } else {
      this.click = 0;
      this.studentsData = JSON.parse(JSON.stringify(this.studentsBackup));
    }
  }

  public ascendingOrder(data: any, sortby: any) {
    return data.sort((a: any, b: any) => {
      let firstfield = typeof a[sortby] === 'number' ? a[sortby] : a[sortby].toLowerCase();
      let nextfield = typeof b[sortby] === 'number' ? b[sortby] : b[sortby].toLowerCase();
      if (firstfield < nextfield) {
        return -1;
      }
      if (firstfield > nextfield) {
        return 1;
      }
      return 0;
    });

  }

  public descendingOrder(data: any, sortby: any) {
    return data.sort((a: any, b: any) => {
      let firstfield = typeof a[sortby] === 'number' ? a[sortby] : a[sortby].toLowerCase();
      let nextfield = typeof b[sortby] === 'number' ? b[sortby] : b[sortby].toLowerCase();
      if (firstfield > nextfield) {
        return -1;
      }
      if (firstfield < nextfield) {
        return 1;
      }
      return 0;
    });
  }

  ngOnDestroy(): void {
    this.studentsData = null;
    this.studentsColumns = null;
    this.studentsBackup = null;
    this.click = null;
  }

}
