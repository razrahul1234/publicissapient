import { Component, Input, OnInit, OnChanges, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-countdowntimer',
  templateUrl: './countdowntimer.component.html',
  styleUrls: ['./countdowntimer.component.css']
})
export class CountdowntimerComponent implements OnInit,OnChanges {
@Input() timerLimit:any;
@Output() public countDownEvent = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges(){
    console.log("value changes : ", this.timerLimit);
  }

}
