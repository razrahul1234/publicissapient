import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-timerlogs',
  templateUrl: './timerlogs.component.html',
  styleUrls: ['./timerlogs.component.css']
})
export class TimerlogsComponent implements OnInit {
  @Input() public timerLogs:any = [];
  constructor() { }

  ngOnInit(): void {
  }

}
