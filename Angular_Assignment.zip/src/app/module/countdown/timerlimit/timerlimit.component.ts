import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-timerlimit',
  templateUrl: './timerlimit.component.html',
  styleUrls: ['./timerlimit.component.css']
})
export class TimerlimitComponent implements OnInit {
  public timerLimit: any;
  public mode: boolean = false;
  public interval: any;
  public timerBackup: any;
  public timerStartedPaused: any = [];
  public started:any=0;
  public paused:any=0;
  public countDownTime:any = [];
  @Output() public timerChange = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  startPauseTimer() {
    if(this.timerLimit && !this.timerBackup){
        this.mode = false;
    }
    this.mode = !this.mode;
    console.log(this.timerLimit);
    if (this.mode && this.timerLimit) {
      if(!this.timerBackup){
        this.timerBackup = this.timerLimit;
      }
      this.timerStartedPaused.push(`Started at ${this.getFormattedDate()}`);
      this.countDownTime.push(`Started at ${this.timerBackup}`);
      this.started=this.started+1;
      this.calculateTimer();
    } else if(this.timerLimit) {
      this.timerStartedPaused.push(`Paused at ${this.getFormattedDate()}`);
      this.countDownTime.push(`Paused at ${this.timerBackup}`);
      this.paused = this.paused+1;
      this.mode = false;
      clearInterval(this.interval);
      this.timerChange.emit({ timerLimit: this.timerBackup, mode: this.mode,timerLogs: this.timerStartedPaused, started:this.started,paused:this.paused});
    }
  }


  resetTimer() {
    this.timerLimit = '';
    this.mode = false;
    this.timerBackup = '';
    this.started='';
    this.paused='';
    this.timerStartedPaused = [];
    this.countDownTime = [];
    this.timerChange.emit({ timerLimit: '', mode: false });
    clearInterval(this.interval);
  }

  calculateTimer() {
    this.interval = setInterval(() => {
      console.log(this.timerBackup);
      if (this.timerBackup) {
        this.timerBackup = this.timerBackup - 1;
        this.timerChange.emit({ timerLimit: this.timerBackup, mode: this.mode,timerLogs: this.timerStartedPaused, started:this.started,paused:this.paused});
      }
    }, 1000)

  }

  getFormattedDate(){
    let pipe = new DatePipe('en-US');
    const now = Date.now();
    const myFormattedDate = pipe.transform(now, 'medium');
    return myFormattedDate;
  }
}
