import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { CountdownComponent } from './countdown/countdown.component';
import { CountdowntimerComponent } from './countdowntimer/countdowntimer.component';
import { TimerlimitComponent } from './timerlimit/timerlimit.component';
import { TimerlogsComponent } from './timerlogs/timerlogs.component';
import { CounterclickComponent } from './counterclick/counterclick.component';
import { FormsModule } from '@angular/forms';
const routes:Routes = [
  {path : '', redirectTo:'countdown', pathMatch:'full'},
   {path :'countdown', component : CountdownComponent}
 ];

@NgModule({
  declarations: [
    CountdownComponent,
    CountdowntimerComponent,
    TimerlimitComponent,
    TimerlogsComponent,
    CounterclickComponent,
    

  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule
  ]
})
export class CountdownModule { }
