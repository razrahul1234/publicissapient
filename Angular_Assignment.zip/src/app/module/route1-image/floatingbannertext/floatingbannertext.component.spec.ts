import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FloatingbannertextComponent } from './floatingbannertext.component';

describe('FloatingbannertextComponent', () => {
  let component: FloatingbannertextComponent;
  let fixture: ComponentFixture<FloatingbannertextComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FloatingbannertextComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FloatingbannertextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
