import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-floatingbannertext',
  templateUrl: './floatingbannertext.component.html',
  styleUrls: ['./floatingbannertext.component.css']
})
export class FloatingbannertextComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
    
  }

}
