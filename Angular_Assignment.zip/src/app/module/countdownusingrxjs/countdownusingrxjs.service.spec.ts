import { TestBed } from '@angular/core/testing';

import { CountdownusingrxjsService } from './countdownusingrxjs.service';

describe('CountdownusingrxjsService', () => {
  let service: CountdownusingrxjsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CountdownusingrxjsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
