import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CountdownusingrxjsComponent } from './countdownusingrxjs.component';

describe('CountdownusingrxjsComponent', () => {
  let component: CountdownusingrxjsComponent;
  let fixture: ComponentFixture<CountdownusingrxjsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CountdownusingrxjsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CountdownusingrxjsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
