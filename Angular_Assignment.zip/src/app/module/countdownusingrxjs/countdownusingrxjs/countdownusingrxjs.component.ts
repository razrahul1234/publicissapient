import { DatePipe } from '@angular/common';
import { Component, OnInit, DoCheck } from '@angular/core';
import { CountdownusingrxjsService } from '../countdownusingrxjs.service';

CountdownusingrxjsService
@Component({
  selector: 'app-countdownusingrxjs',
  templateUrl: './countdownusingrxjs.component.html',
  styleUrls: ['./countdownusingrxjs.component.css']
})
export class CountdownusingrxjsComponent implements OnInit, DoCheck {
  public timerLimit:any;
  public timerBackup:any;
  public timerLogs:any = [];
  public started:number=0;
  public paused:number=0;
  public mode:boolean = false;
  public countDownTime:any = [];
  constructor(private counteServcie:CountdownusingrxjsService) { }

  ngOnInit(): void {
    this.calculateTimer();
  }

  public calculateTimer(){
    this.counteServcie.subject.subscribe({
      next :(value) => { 
        console.log(value) ;
        this.mode = !this.mode;
        if(this.mode && this.timerLimit){
          if(!this.timerBackup){
            this.timerBackup = this.timerLimit;
          }
          this.started++;
          this.timerLogs.push(`Started at ${this.getFormattedDate()}`);
          this.countDownTime.push(`Started at ${this.timerBackup}`);
          this.computeTimer();
        } else {
          this.paused++;
          clearInterval(this.interval);
          this.timerLogs.push(`Paused at ${this.getFormattedDate()}`);
          this.countDownTime.push(`Started at ${this.timerBackup}`);
        }
        
      },
      error : (error) => console.log(error),
      complete : ()=> console.log("complete")
    })
  }


  //timer limit logic
public interval:any;
 public startPauseTimer(){
   if(this.timerLimit){
    this.counteServcie.setTimer(this.timerLimit);
   }
 } 

 public resetTimer(){
   this.timerLimit = '';
   this.timerBackup = '';
   this.mode = false;
   this.started = 0;
   this.paused = 0;
   this.timerLogs =[];
   this.countDownTime = [];
   clearInterval(this.interval);
 }

 computeTimer() {
  this.interval = setInterval(() => {
    if (this.timerBackup) {
         this.timerBackup = this.timerBackup - 1;
    }
  }, 1000)

}

getFormattedDate(){
  let pipe = new DatePipe('en-US');
  const now = Date.now();
  const myFormattedDate = pipe.transform(now, 'medium');
  return myFormattedDate;
}

ngDoCheck(){
  if(this.interval && this.timerLimit && this.timerBackup === 0){
    setTimeout(()=>{
      this.timerBackup = '';
      this.mode = false;
      clearInterval(this.interval);
    },1000)
  }
}
}
