import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CountdownusingrxjsComponent } from './countdownusingrxjs/countdownusingrxjs.component';
import { RouterModule, Routes } from '@angular/router';
import { CountdownusingrxjsService } from './countdownusingrxjs.service';
import { FormsModule } from '@angular/forms';

const routes:Routes = [
  {path : '', redirectTo:'countdownusingrxjs', pathMatch:'full'},
   {path :'countdownusingrxjs', component : CountdownusingrxjsComponent}
 ];

@NgModule({
  declarations: [
    CountdownusingrxjsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  providers:[CountdownusingrxjsService]
})
export class CountdownusingrxjsModule { }
