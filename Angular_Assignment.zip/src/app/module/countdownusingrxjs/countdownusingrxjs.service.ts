import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CountdownusingrxjsService {
 public subject = new Subject();
  constructor() { }

  public setTimer(value:any){
    this.subject.next(value);
  }
}
