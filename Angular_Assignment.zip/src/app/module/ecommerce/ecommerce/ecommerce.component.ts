import { Component, OnInit } from '@angular/core';
import { EcommereService } from '../ecommere.service';

@Component({
  selector: 'app-ecommerce',
  templateUrl: './ecommerce.component.html',
  styleUrls: ['./ecommerce.component.css']
})
export class EcommerceComponent implements OnInit {
  public products:Array<any> = [];
  public gridTemplateColumns:string='repeat(auto-fill, minmax(280px, 1fr))';

  constructor(private ecommerceService: EcommereService) { }

  ngOnInit(): void {
    this.fetchProducts();
  }

  public fetchProducts() {
    this.ecommerceService.fetchProduct().subscribe({
      next: res => {
        console.log(res);
        this.products = res.products;
      }
      ,error: (error) => console.log(error)
    }
    )
  }

  public sortProducts(event:any){
     console.log(event);
     if(event.target.value === 'ascending'){
      this.products.sort((a,b) => a.price - b.price);
     } else if(event.target.value === 'descending') {
      this.products.sort((a,b) => b.price - a.price);
     }
  }

  public changeView(view:string){
    if(view === 'grid'){
      this.gridTemplateColumns = "repeat(auto-fill, minmax(280px, 1fr))"
    } else if(view === 'list'){
      this.gridTemplateColumns = "repeat(auto-fill, minmax(500px, 1fr))"
    }
  }

}
