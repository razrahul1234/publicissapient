import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EcommerceComponent } from './ecommerce/ecommerce.component';
import { RouterModule, Routes } from '@angular/router';
import { EcommereService } from './ecommere.service';

const routes:Routes = [
  {path : '', redirectTo:'ecommerce', pathMatch:'full'},
  {path :'ecommerce', component : EcommerceComponent}
 ];


@NgModule({
  declarations: [
    EcommerceComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  providers:[EcommereService]
})
export class EcommerceModule { }
