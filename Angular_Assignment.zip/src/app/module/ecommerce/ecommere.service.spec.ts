import { TestBed } from '@angular/core/testing';

import { EcommereService } from './ecommere.service';

describe('EcommereService', () => {
  let service: EcommereService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EcommereService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
