import { Component, OnInit } from '@angular/core';
import { AppserviceService } from './appservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'angular-assignment';
  menuResponse: Array<any> = [];

  constructor(private appService: AppserviceService) { }

  ngOnInit() {
    this.fetchMenu()
  }

  public fetchMenu() {

    this.appService.getMenuData().subscribe((res) => { 
      console.log(res);
      this.menuResponse = res.menu; 
    }, error => {
      console.log(error);
    }
    )
  }
}
