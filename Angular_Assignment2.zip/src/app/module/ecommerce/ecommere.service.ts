import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class EcommereService {

  constructor(private http:HttpClient) { }

  public fetchProduct():Observable<any>{
    return this.http.get("/assets/data/products.json");
  }
}
