import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DynamicdivComponent } from './dynamicdiv/dynamicdiv.component';
import { RouterModule, Routes } from '@angular/router';

const routes:Routes = [
  {path : '', redirectTo:'dynamicdiv', pathMatch:'full'},
  {path :'dynamicdiv', component : DynamicdivComponent}
 ];

@NgModule({
  declarations: [
    DynamicdivComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class DynamicModule { }
