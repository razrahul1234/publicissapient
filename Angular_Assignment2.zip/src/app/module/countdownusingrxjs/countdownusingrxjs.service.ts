import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class CountdownusingrxjsService {
 public subject = new Subject();
 public timerlogs = new Subject();
 public clicksOperation = new Subject();
 public countDown:number = 0;

  constructor() { }

  public setTimerLimit(value:any){
    this.subject.next(value);
  }

  public setTimerLogs(value:string){
    console.log(value);
    this.timerlogs.next(value);
  }

  public setClicksOperation(value:any){
    console.log(value);
    this.clicksOperation.next(value);
  }

}
