import { Component, OnInit } from '@angular/core';
import { CountdownusingrxjsService } from '../countdownusingrxjs.service';

@Component({
  selector: 'app-timerlogs',
  templateUrl: './timerlogs.component.html',
  styleUrls: ['./timerlogs.component.css']
})
export class TimerlogsComponent implements OnInit {
  timerLogs: any = [];
  constructor(private counterService: CountdownusingrxjsService) { }

  ngOnInit(): void {
    this.getLogs();
  }

  public getLogs() {
    this.counterService.timerlogs.subscribe({
      next: (res) => {
        console.log(res);
        if (res === 'reset') {
          this.timerLogs = [];
        } else {
          this.timerLogs.push(res);
        }
      },
      error: (error) => console.log(error),
      complete: () => {
        console.log();

      }
    }
    )

  }

}
