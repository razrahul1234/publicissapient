import { Component, OnInit } from '@angular/core';
import { CountdownusingrxjsService } from '../countdownusingrxjs.service';

@Component({
  selector: 'app-counterclick',
  templateUrl: './counterclick.component.html',
  styleUrls: ['./counterclick.component.css']
})
export class CounterclickComponent implements OnInit {
  public started:any=0;
  public paused:any=0;
  constructor(private counterService:CountdownusingrxjsService) { }

  ngOnInit(): void {
    this.clicksOperation();
  }

  public clicksOperation() {
    this.counterService.clicksOperation.subscribe({
      next: (res) => {
        console.log(res);
        if(res === 'reset'){
          this.started = null;
          this.paused = null;
        }else if(res == "start"){
          this.started = this.started + 1;
        } else {
          this.paused = this.paused + 1;
        }
      },
      error: (error) => console.log(error),
      complete: () => {}
    }
    )
  }
}
