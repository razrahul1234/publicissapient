import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CountdownusingrxjsComponent } from './countdownusingrxjs/countdownusingrxjs.component';
import { RouterModule, Routes } from '@angular/router';
import { CountdownusingrxjsService } from './countdownusingrxjs.service';
import { FormsModule } from '@angular/forms';
import { CountdowntimerComponent } from './countdowntimer/countdowntimer.component';
import { CounterclickComponent } from './counterclick/counterclick.component';
import { TimerlimitComponent } from './timerlimit/timerlimit.component';
import { TimerlogsComponent } from './timerlogs/timerlogs.component';

const routes:Routes = [
  {path : '', redirectTo:'countdownusingrxjs', pathMatch:'full'},
   {path :'countdownusingrxjs', component : CountdownusingrxjsComponent}
 ];

@NgModule({
  declarations: [
    CountdownusingrxjsComponent,
    CountdowntimerComponent,
    CounterclickComponent,
    TimerlimitComponent,
    TimerlogsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  providers:[CountdownusingrxjsService]
})
export class CountdownusingrxjsModule { }
