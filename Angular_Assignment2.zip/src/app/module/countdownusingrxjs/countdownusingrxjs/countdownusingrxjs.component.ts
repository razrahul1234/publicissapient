import { DatePipe } from '@angular/common';
import { Component, OnInit, DoCheck } from '@angular/core';
import { CountdownusingrxjsService } from '../countdownusingrxjs.service';

CountdownusingrxjsService
@Component({
  selector: 'app-countdownusingrxjs',
  templateUrl: './countdownusingrxjs.component.html',
  styleUrls: ['./countdownusingrxjs.component.css']
})
export class CountdownusingrxjsComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
}
