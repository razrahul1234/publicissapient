import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-countdown',
  templateUrl: './countdown.component.html',
  styleUrls: ['./countdown.component.css']
})
export class CountdownComponent implements OnInit {
  public timerLimit:any;
  public timerLogs:any=[];
  started:any;
  paused:any;
  constructor() { }

  ngOnInit(): void {
  }

  timerChange(event:any){
    console.log(event);
    this.timerLimit = event.timerLimit;
    this.timerLogs = event.timerLogs;
    this.started = event.started;
    this.paused = event.paused;
  }
}
