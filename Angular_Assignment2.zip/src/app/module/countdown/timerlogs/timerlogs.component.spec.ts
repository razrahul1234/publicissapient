import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimerlogsComponent } from './timerlogs.component';

describe('TimerlogsComponent', () => {
  let component: TimerlogsComponent;
  let fixture: ComponentFixture<TimerlogsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TimerlogsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TimerlogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
