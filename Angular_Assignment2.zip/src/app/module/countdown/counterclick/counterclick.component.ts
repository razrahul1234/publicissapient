import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-counterclick',
  templateUrl: './counterclick.component.html',
  styleUrls: ['./counterclick.component.css']
})
export class CounterclickComponent implements OnInit {
@Input() public started:any;
@Input() public paused:any;
  constructor() { }

  ngOnInit(): void {
  }

}
