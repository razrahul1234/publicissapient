import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CounterclickComponent } from './counterclick.component';

describe('CounterclickComponent', () => {
  let component: CounterclickComponent;
  let fixture: ComponentFixture<CounterclickComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CounterclickComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CounterclickComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
